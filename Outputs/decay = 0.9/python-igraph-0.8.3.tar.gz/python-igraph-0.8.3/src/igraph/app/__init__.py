"""User interfaces of igraph"""

